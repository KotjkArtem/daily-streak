package com.dailystreak.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Context.dataStore by preferencesDataStore(name = "daily_streak")
private val GREEN = Color(0xFF245B45)
private val PALE = Color(0xFFF4F7F4)
private val DONE = Color(0xFF3D9366)
private val MISSED = Color(0xFFD96B65)
private val SAVED = Color(0xFFE4B34F)

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { DailyStreakApp() }
    }
    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel("daily_streak_reminders", "Напоминания Daily Streak", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }
}

@Composable
fun DailyStreakApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf(0) }
    var records by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var reminder1 by remember { mutableStateOf("12:00") }
    var reminder2 by remember { mutableStateOf("20:00") }
    var enabled1 by remember { mutableStateOf(true) }
    var enabled2 by remember { mutableStateOf(true) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val p = context.dataStore.data.first()
        records = decodeRecords(p[stringPreferencesKey("records")].orEmpty())
        reminder1 = p[stringPreferencesKey("reminder1")] ?: "12:00"
        reminder2 = p[stringPreferencesKey("reminder2")] ?: "20:00"
        enabled1 = p[stringPreferencesKey("enabled1")] != "false"
        enabled2 = p[stringPreferencesKey("enabled2")] != "false"
    }
    fun save() {
        scope.launch {
            context.dataStore.edit {
                it[stringPreferencesKey("records")] = encodeRecords(records)
                it[stringPreferencesKey("reminder1")] = reminder1
                it[stringPreferencesKey("reminder2")] = reminder2
                it[stringPreferencesKey("enabled1")] = enabled1.toString()
                it[stringPreferencesKey("enabled2")] = enabled2.toString()
            }
        }
    }
    val today = LocalDate.now()
    val streak = calculateStreak(records, today)
    val best = calculateBest(records)
    val usedRescue = records.values.count { it == "saved" && LocalDate.parse(records.entries.first { e -> e.value == it }.key).isAfter(today.minusDays(7)) } > 0
    MaterialTheme(colorScheme = lightColorScheme(primary = GREEN, background = PALE, surface = Color.White)) {
        Scaffold(
            containerColor = PALE,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == 0, onClick = { page = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                    NavigationBarItem(selected = page == 1, onClick = { page = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Календарь") })
                    NavigationBarItem(selected = page == 2, onClick = { page = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                Text("DAILY STREAK", color = GREEN, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    0 -> HomePage(streak, best, records[today.toString()] == "done", usedRescue,
                        onDone = {
                            records = records + (today.toString() to "done"); message = "Тренировка отмечена!"; save()
                        },
                        onRescue = {
                            val yesterday = today.minusDays(1).toString()
                            val lastRescue = records.filterValues { it == "saved" }.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.maxOrNull()
                            if (lastRescue == null || !lastRescue.isAfter(today.minusDays(7))) {
                                if (records[yesterday] == null && records[today.toString()] != "done") {
                                    records = records + (yesterday to "saved")
                                    message = "Серия спасена за вчера"; save()
                                } else message = "Сегодня нечего спасать или день уже отмечен"
                            } else message = "Спасение уже использовано за последние 7 дней"
                        }, message = message, onMessage = { message = "" })
                    1 -> CalendarPage(month, records, onMonth = { month = it })
                    2 -> SettingsPage(reminder1, reminder2, enabled1, enabled2,
                        onTime1 = { reminder1 = it; save() }, onTime2 = { reminder2 = it; save() },
                        onEnabled1 = { enabled1 = it; save() }, onEnabled2 = { enabled2 = it; save() })
                }
            }
        }
    }
}

@Composable
fun HomePage(streak: Int, best: Int, done: Boolean, rescueUsed: Boolean, onDone: () -> Unit,
             onRescue: () -> Unit, message: String, onMessage: () -> Unit) {
    val flame = when {
        streak == 0 -> ""
        streak < 4 -> "🔥"
        streak < 8 -> "🔥"
        streak < 15 -> "🔥🔥"
        streak < 30 -> "🔥🔥"
        streak < 60 -> "🔥🔥🔥"
        else -> "🔥🔥🔥"
    }
    Spacer(Modifier.height(28.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(vertical = 30.dp, horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ТВОЯ СЕРИЯ", color = GREEN, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(14.dp))
            Text(flame, fontSize = 42.sp)
            Text("$streak", fontSize = 64.sp, fontWeight = FontWeight.Bold, color = GREEN)
            Text(if (streak == 1) "день подряд" else "дней подряд", color = Color.Gray)
            Spacer(Modifier.height(22.dp))
            Button(onClick = onDone, enabled = !done, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Text(if (done) "Тренировка отмечена" else "Я сделал зарядку", fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onRescue, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Спасти серию")
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$best", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = GREEN)
                    Text("Рекорд", color = Color.Gray, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (rescueUsed) "0" else "1", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = GREEN)
                    Text("Спасений доступно", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
    if (message.isNotBlank()) {
        Spacer(Modifier.height(12.dp))
        Text(message, color = GREEN, modifier = Modifier.clickable { onMessage() }.padding(8.dp))
    }
    Spacer(Modifier.height(12.dp))
    Text("Не обязательно идеально. Главное — продолжать.", color = Color.Gray, fontSize = 13.sp)
}

@Composable
fun CalendarPage(month: YearMonth, records: Map<String, String>, onMonth: (YearMonth) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { onMonth(month.minusMonths(1)) }) { Text("‹") }
        Text(month.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale("ru"))).replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold)
        TextButton(onClick = { onMonth(month.plusMonths(1)) }) { Text("›") }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
        listOf("Пн","Вт","Ср","Чт","Пт","Сб","Вс").forEach { Text(it, fontSize = 11.sp, color = Color.Gray) }
    }
    val offset = month.atDay(1).dayOfWeek.value - 1
    val cells = (List(offset) { "" } + (1..month.lengthOfMonth()).map { it.toString() })
    LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.fillMaxWidth().height(300.dp), userScrollEnabled = false) {
        items(cells) { day ->
            Box(Modifier.aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                if (day.isNotBlank()) {
                    val key = month.atDay(day.toInt()).toString()
                    val status = records[key]
                    val color = when(status) { "done" -> DONE; "saved" -> SAVED; "missed" -> MISSED; else -> Color(0xFFE9EDEA) }
                    Box(Modifier.fillMaxSize().background(color, CircleShape), contentAlignment = Alignment.Center) {
                        Text(day, color = if (status == null) Color.DarkGray else Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Legend(DONE, "Тренировка"); Legend(SAVED, "Спасение"); Legend(MISSED, "Пропуск")
    }
    Text("Пропущенные дни до сегодняшней даты отображаются серым; история ведётся с момента установки.", fontSize = 11.sp, color = Color.Gray)
}

@Composable
fun Legend(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(color, CircleShape))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = Color.Gray)
    }
}

@Composable
fun SettingsPage(t1: String, t2: String, e1: Boolean, e2: Boolean,
                 onTime1: (String) -> Unit, onTime2: (String) -> Unit,
                 onEnabled1: (Boolean) -> Unit, onEnabled2: (Boolean) -> Unit) {
    Text("Напоминания", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = GREEN)
    Spacer(Modifier.height(12.dp))
    ReminderRow("Первое напоминание", t1, e1, onTime1, onEnabled1)
    Divider()
    ReminderRow("Второе напоминание", t2, e2, onTime2, onEnabled2)
    Spacer(Modifier.height(18.dp))
    Text("Время можно менять в формате ЧЧ:ММ. Настройки сохраняются на устройстве.", color = Color.Gray, fontSize = 12.sp)
    Spacer(Modifier.height(20.dp))
    Text("Daily Streak · версия 1.0", color = Color.Gray, fontSize = 12.sp)
}

@Composable
fun ReminderRow(title: String, time: String, enabled: Boolean, onTime: (String) -> Unit, onEnabled: (Boolean) -> Unit) {
    var edit by remember(time) { mutableStateOf(time) }
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Switch(checked = enabled, onCheckedChange = onEnabled)
        }
        OutlinedTextField(value = edit, onValueChange = { edit = it.take(5) }, label = { Text("Время (например, 12:00)") }, singleLine = true)
        TextButton(onClick = { if (edit.matches(Regex("^([01]\\d|2[0-3]):[0-5]\\d$"))) onTime(edit) }) { Text("Сохранить время") }
    }
}

fun encodeRecords(map: Map<String, String>) = map.entries.joinToString(";") { "${it.key}=${it.value}" }
fun decodeRecords(value: String): Map<String, String> = if (value.isBlank()) emptyMap() else value.split(";").mapNotNull {
    val p = it.split("="); if (p.size == 2) p[0] to p[1] else null
}.toMap()

fun calculateStreak(records: Map<String, String>, today: LocalDate): Int {
    var date = if (records[today.toString()] == "done") today else today.minusDays(1)
    if (records[date.toString()] !in listOf("done", "saved")) return 0
    var count = 0
    while (records[date.toString()] in listOf("done", "saved")) { count++; date = date.minusDays(1) }
    return count
}
fun calculateBest(records: Map<String, String>): Int {
    val dates = records.filterValues { it == "done" || it == "saved" }.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    var best = 0; var current = 0; var previous: LocalDate? = null
    for (d in dates) {
        current = if (previous != null && d == previous!!.plusDays(1)) current + 1 else 1
        best = maxOf(best, current); previous = d
    }
    return best
}
