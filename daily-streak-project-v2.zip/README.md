# Daily Streak

Personal Android workout streak tracker.

## Build
GitHub Actions builds a debug APK on pushes to `main` or via **Actions → Build Daily Streak APK → Run workflow**.

The APK is uploaded as the workflow artifact `daily-streak-debug-apk`.

This is an early prototype. Reminder scheduling and a fully validated rescue/streak policy are still being implemented and tested.
