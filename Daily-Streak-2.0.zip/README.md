# Daily Streak 4.0

Android habit tracker with streak tracking, selectable unlocked flame collection, workout-count achievements (10, 50, 100, 200, 365), custom launcher icon, rotating motivational reminders, and reminder suppression after today's workout is completed.

The existing application ID and debug signing keystore are retained for in-place updates.
