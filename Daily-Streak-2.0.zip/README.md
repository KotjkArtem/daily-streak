# Daily Streak 3.0

Personal Android workout streak tracker.

## Version 3.0
- Adds a game-style collection of nine flame achievements (1, 3, 7, 14, 21, 30, 60, 100 and 365 days).
- Unlocked flames remain available because unlocks are derived from the best recorded streak.
- The home screen shows the flame for the current streak.
- Tapping a reminder notification opens the main app screen.
- Keeps the existing workout history, rescue logic, calendar, statistics and reminder settings.
- Increments Android versionCode to 2 and versionName to 3.0.

## Build
Upload this ZIP to the root of the GitHub repository using the existing workflow, which extracts the ZIP and runs `assembleDebug`.

The included `app/daily-streak-debug.keystore` is retained from version 2.0 so builds made with this archive use the same debug signing certificate. Keep this file private and do not replace it; it is required for installing updates over the previous build.
