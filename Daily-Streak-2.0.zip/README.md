# Daily Streak 2.0

Personal Android workout tracker.

This archive contains the Android project source. Upload the archive to the root of the GitHub repository using the existing repository workflow, which extracts this archive and runs `assembleDebug`.

Version 2.0 adds scheduled daily reminders, notification-time settings, calendar missed-day coloring, monthly completion statistics, a streak flame level, and a migration path for records/settings from version 1.0.

The debug signing key is intentionally fixed for this personal project so subsequent APK builds can be installed as updates over version 2.0 without changing the signing certificate. It is a development key, not a production release key.
