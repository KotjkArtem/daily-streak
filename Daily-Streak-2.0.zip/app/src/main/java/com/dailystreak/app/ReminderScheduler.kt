package com.dailystreak.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.ZoneId

object ReminderScheduler {
    private const val CHANNEL = "daily_streak_reminders"
    private const val PREFS = "daily_streak_v2"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "Напоминания Daily Streak", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Ежедневные напоминания о тренировке"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun scheduleAll(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        schedule(context, 1, p.getString("reminder1", "12:00") ?: "12:00", p.getBoolean("enabled1", true))
        schedule(context, 2, p.getString("reminder2", "20:00") ?: "20:00", p.getBoolean("enabled2", true))
    }

    fun schedule(context: Context, id: Int, time: String, enabled: Boolean) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("id", id)
        val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.cancel(pi)
        if (!enabled) return
        val parts = time.split(":")
        if (parts.size != 2) return
        val h = parts[0].toIntOrNull() ?: return
        val m = parts[1].toIntOrNull() ?: return
        if (h !in 0..23 || m !in 0..59) return
        val now = LocalDateTime.now()
        var next = now.toLocalDate().atTime(h, m)
        if (!next.isAfter(now)) next = next.plusDays(1)
        val millis = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.createChannel(context)
        val id = intent.getIntExtra("id", 1)
        val title = "Daily Streak"
        val p = context.getSharedPreferences("daily_streak_v2", Context.MODE_PRIVATE)
        val todayKey = LocalDate.now().toString()
        val todayDone = (p.getString("records", "") ?: "")
            .split(";")
            .any { entry ->
                val parts = entry.split("=")
                parts.size == 2 && parts[0] == todayKey && parts[1] == "done"
            }

        // If the user has already completed today's workout, stay silent for this reminder.
        if (todayDone) {
            val key = if (id == 1) "reminder1" else "reminder2"
            val enabledKey = if (id == 1) "enabled1" else "enabled2"
            ReminderScheduler.schedule(
                context, id,
                p.getString(key, if (id == 1) "12:00" else "20:00") ?: if (id == 1) "12:00" else "20:00",
                p.getBoolean(enabledKey, true)
            )
            return
        }

        val morningMessages = listOf(
            "Новый день — новый шанс разжечь свой огонёк!",
            "Твоя серия ждёт продолжения. Готов к зарядке?",
            "Даже короткая тренировка — шаг к большой цели.",
            "Зажги сегодняшний день движением!",
            "Пять минут активности лучше, чем ноль. Начнём?"
        )
        val eveningMessages = listOf(
            "Не дай огоньку погаснуть. Ещё есть время!",
            "Каждая отметка приближает тебя к следующему огоньку.",
            "Ты уже ближе к цели, чем вчера. Продолжай!",
            "Закрепи сегодняшний успех — серия любит регулярность.",
            "Проверь свой прогресс и отметь сегодняшнюю тренировку."
        )
        val messageIndex = (LocalDate.now().dayOfYear + id) % 5
        val body = if (id == 1) morningMessages[messageIndex] else eveningMessages[messageIndex]
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context, 200 + id, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "daily_streak_reminders")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openAppPendingIntent)
            .setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(100 + id, notification) } catch (_: SecurityException) { }
        val key = if (id == 1) "reminder1" else "reminder2"
        val enabled = if (id == 1) "enabled1" else "enabled2"
        ReminderScheduler.schedule(context, id, p.getString(key, if (id == 1) "12:00" else "20:00") ?: "12:00", p.getBoolean(enabled, true))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.scheduleAll(context)
    }
}
