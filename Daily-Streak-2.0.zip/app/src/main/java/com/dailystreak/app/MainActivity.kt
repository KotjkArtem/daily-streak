package com.dailystreak.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

private const val PREFS = "daily_streak_v2"
private val Context.legacyStore by preferencesDataStore(name = "daily_streak")
private val green = Color(0xFF245B45)
private val pale = Color(0xFFF4F7F4)
private val completed = Color(0xFF3D9366)
private val missed = Color(0xFFD96B65)
private val rescued = Color(0xFFE4B34F)

private val flameLevels = listOf(
    FlameLevel(1, "Искра", "Начало твоего пути", listOf(Color(0xFFFFF176), Color(0xFFFF9800), Color(0xFFE65100))),
    FlameLevel(3, "Живая искра", "Пламя набирает силу", listOf(Color(0xFFFFF59D), Color(0xFFFFB300), Color(0xFFF4511E))),
    FlameLevel(7, "Оранжевое пламя", "Первая неделя", listOf(Color(0xFFFFE082), Color(0xFFFF6D00), Color(0xFFBF360C))),
    FlameLevel(14, "Синее пламя", "Две недели дисциплины", listOf(Color(0xFFB3E5FC), Color(0xFF29B6F6), Color(0xFF1565C0))),
    FlameLevel(21, "Бирюзовое пламя", "Три недели подряд", listOf(Color(0xFFB2DFDB), Color(0xFF26A69A), Color(0xFF00695C))),
    FlameLevel(30, "Фиолетовое пламя", "Месяц регулярности", listOf(Color(0xFFE1BEE7), Color(0xFFAB47BC), Color(0xFF6A1B9A))),
    FlameLevel(60, "Золотое пламя", "Шестьдесят дней силы воли", listOf(Color(0xFFFFF9C4), Color(0xFFFFC107), Color(0xFFF57F17))),
    FlameLevel(100, "Легендарное пламя", "Сто дней без остановки", listOf(Color(0xFFF8BBD0), Color(0xFFE91E63), Color(0xFF880E4F))),
    FlameLevel(365, "Королевское пламя", "Год постоянства", listOf(Color(0xFFFFFFFF), Color(0xFF90CAF9), Color(0xFF5E35B1)))
)
private data class FlameLevel(val days: Int, val name: String, val description: String, val colors: List<Color>)
private fun flameIndex(days: Int): Int = flameLevels.indexOfLast { days >= it.days }.coerceAtLeast(0)

class MainActivity : ComponentActivity() {
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        ReminderScheduler.scheduleAll(this)
        setContent { DailyStreakApp() }
    }
}

@Composable
fun DailyStreakApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var page by remember { mutableIntStateOf(0) }
    var records by remember { mutableStateOf(readRecords(prefs)) }
    var t1 by remember { mutableStateOf(prefs.getString("reminder1", "12:00") ?: "12:00") }
    var t2 by remember { mutableStateOf(prefs.getString("reminder2", "20:00") ?: "20:00") }
    var e1 by remember { mutableStateOf(prefs.getBoolean("enabled1", true)) }
    var e2 by remember { mutableStateOf(prefs.getBoolean("enabled2", true)) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        // Import the first prototype's DataStore data so the user's existing streak is preserved.
        val old = context.legacyStore.data.first()
        val oldRecords = old[stringPreferencesKey("records")]
        if (prefs.getString("records", null) == null && !oldRecords.isNullOrBlank()) {
            prefs.edit().putString("records", oldRecords)
                .putString("reminder1", old[stringPreferencesKey("reminder1")] ?: "12:00")
                .putString("reminder2", old[stringPreferencesKey("reminder2")] ?: "20:00")
                .putBoolean("enabled1", old[stringPreferencesKey("enabled1")] != "false")
                .putBoolean("enabled2", old[stringPreferencesKey("enabled2")] != "false")
                .apply()
            records = readRecords(prefs)
            t1 = prefs.getString("reminder1", "12:00") ?: "12:00"
            t2 = prefs.getString("reminder2", "20:00") ?: "20:00"
            e1 = prefs.getBoolean("enabled1", true)
            e2 = prefs.getBoolean("enabled2", true)
            ReminderScheduler.scheduleAll(context)
        }
    }
    val today = LocalDate.now()
    val streak = streakNow(records, today)
    val best = bestStreak(records)
    val total = records.values.count { it == "done" }
    val lastRescue = records.filterValues { it == "saved" }.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.maxOrNull()
    val rescueReady = lastRescue == null || !lastRescue.isAfter(today.minusDays(7))
    val canRescue = rescueReady && records[today.toString()] != "done" && records[today.minusDays(1).toString()] == null && (records[today.minusDays(2).toString()] == "done" || records[today.minusDays(2).toString()] == "saved")
    fun persist() { prefs.edit().putString("records", writeRecords(records)).apply() }

    MaterialTheme(colorScheme = lightColorScheme(primary = green, background = pale, surface = Color.White)) {
        Scaffold(containerColor = pale, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(page == 0, { page = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") })
                NavigationBarItem(page == 1, { page = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Календарь") })
                NavigationBarItem(page == 2, { page = 2 }, icon = { Icon(Icons.Default.Star, null) }, label = { Text("Коллекция") })
                NavigationBarItem(page == 3, { page = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("DAILY STREAK", color = green, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    0 -> HomePage(streak, best, total, records[today.toString()] == "done", canRescue, rescueReady, note,
                        onDone = { records = records + (today.toString() to "done"); persist(); note = "Тренировка отмечена!" },
                        onRescue = {
                            if (canRescue) { records = records + (today.minusDays(1).toString() to "saved"); persist(); note = "Вчерашний день спасён. Серия сохранена!" }
                            else note = when { !rescueReady -> "Спасение снова доступно ${lastRescue?.plusDays(7)?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))}"; records[today.toString()] == "done" -> "Сегодня тренировка уже отмечена."; else -> "Сейчас нет подходящего пропущенного дня для спасения." }
                        }, onClear = { note = "" })
                    1 -> CalendarPage(month, records, { month = it })
                    2 -> CollectionPage(best, streak)
                    else -> SettingsPage(t1, t2, e1, e2, note,
                        { t1 = it }, { t2 = it },
                        { e1 = it; prefs.edit().putBoolean("enabled1", it).apply(); ReminderScheduler.schedule(context, 1, t1, it) },
                        { e2 = it; prefs.edit().putBoolean("enabled2", it).apply(); ReminderScheduler.schedule(context, 2, t2, it) },
                        { if (validTime(t1)) { prefs.edit().putString("reminder1", t1).apply(); ReminderScheduler.schedule(context, 1, t1, e1); note = "Первое напоминание сохранено." } else note = "Введи время в формате ЧЧ:ММ, например 12:00." },
                        { if (validTime(t2)) { prefs.edit().putString("reminder2", t2).apply(); ReminderScheduler.schedule(context, 2, t2, e2); note = "Второе напоминание сохранено." } else note = "Введи время в формате ЧЧ:ММ, например 20:00." }, { note = "" })
                }
            }
        }
    }
}

@Composable
private fun HomePage(streak: Int, best: Int, total: Int, done: Boolean, canRescue: Boolean, rescueReady: Boolean, note: String, onDone: () -> Unit, onRescue: () -> Unit, onClear: () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "flame").animateFloat(0.96f, 1.04f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val activeFlameIndex = flameIndex(streak.coerceAtLeast(1))
    val level = if (streak == 0) "Начни новую серию" else flameLevels[activeFlameIndex].name
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 26.dp, horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ТВОЯ СЕРИЯ", color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(12.dp))
            if (streak > 0) FlameVisual(activeFlameIndex, Modifier.size(82.dp).scale(pulse)) else Text("—", fontSize = 42.sp, color = Color.LightGray)
            Text("$streak", fontSize = 62.sp, fontWeight = FontWeight.Bold, color = green)
            Text(if (streak == 1) "день подряд" else "дней подряд", color = Color.Gray)
            if (streak > 0) Text(level, color = green, fontSize = 12.sp)
            Text("Новые огоньки открываются за серии 1–365 дней", color = Color.Gray, fontSize = 10.sp)
            Spacer(Modifier.height(18.dp))
            Button(onClick = onDone, enabled = !done, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text(if (done) "Тренировка отмечена" else "Я сделал зарядку", fontSize = 16.sp) }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onRescue, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("Спасти серию") }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Metric("$best", "Рекорд"); Metric("$total", "Тренировок"); Metric(if (rescueReady) "1" else "0", "Спасений доступно") }
        }
    }
    if (note.isNotBlank()) Text(note, color = green, modifier = Modifier.clickable { onClear() }.padding(8.dp))
    Spacer(Modifier.height(12.dp))
    Text("Не обязательно идеально. Главное — продолжать.", color = Color.Gray, fontSize = 13.sp)
}


@Composable
private fun FlameVisual(index: Int, modifier: Modifier = Modifier, locked: Boolean = false) {
    val colors = if (locked) listOf(Color(0xFFB0B7B2), Color(0xFF87918A), Color(0xFF66716A)) else flameLevels[index].colors
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val outer = Path().apply {
            moveTo(w * .50f, h * .03f)
            cubicTo(w * .43f, h * .20f, w * .18f, h * .35f, w * .20f, h * .62f)
            cubicTo(w * .21f, h * .88f, w * .36f, h * .98f, w * .52f, h * .98f)
            cubicTo(w * .76f, h * .98f, w * .88f, h * .79f, w * .84f, h * .58f)
            cubicTo(w * .82f, h * .42f, w * .67f, h * .28f, w * .65f, h * .14f)
            cubicTo(w * .61f, h * .28f, w * .54f, h * .34f, w * .50f, h * .03f)
            close()
        }
        drawPath(outer, Brush.verticalGradient(colors, startY = 0f, endY = h))
        val inner = Path().apply {
            moveTo(w * .51f, h * .43f)
            cubicTo(w * .45f, h * .57f, w * .35f, h * .65f, w * .39f, h * .80f)
            cubicTo(w * .42f, h * .91f, w * .61f, h * .93f, w * .66f, h * .80f)
            cubicTo(w * .72f, h * .65f, w * .57f, h * .55f, w * .51f, h * .43f)
            close()
        }
        drawPath(inner, Brush.verticalGradient(listOf(Color(0xFFFFFDE7), Color(0xFFFFE082), Color(0xFFFF8F00)), startY = h * .4f, endY = h))
    }
}

@Composable
private fun CollectionPage(best: Int, current: Int) {
    var selected by remember { mutableIntStateOf(flameIndex(best.coerceAtLeast(1))) }
    val level = flameLevels[selected]
    val unlocked = best >= level.days
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Коллекция огоньков", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = green)
        Spacer(Modifier.height(4.dp))
        Text("Открыто: ${flameLevels.count { best >= it.days }} из ${flameLevels.size}", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                FlameVisual(selected, Modifier.size(104.dp), locked = !unlocked)
                Text(if (unlocked) level.name else "???", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = green)
                Text(if (unlocked) level.description else "Откроется на серии ${level.days} дней", color = Color.Gray, fontSize = 12.sp)
                Text(if (unlocked) "Получено за рекордную серию" else "Осталось: ${(level.days - best).coerceAtLeast(0)} дн.", color = if (unlocked) green else Color.Gray, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxWidth().height(270.dp), userScrollEnabled = true) {
            items(flameLevels.size) { i ->
                val item = flameLevels[i]
                val isUnlocked = best >= item.days
                Card(
                    Modifier.padding(5.dp).fillMaxWidth().clickable { selected = i },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (selected == i) Color(0xFFE4EFE8) else Color.White),
                    border = if (selected == i) androidx.compose.foundation.BorderStroke(1.dp, green) else null
                ) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        FlameVisual(i, Modifier.size(48.dp), locked = !isUnlocked)
                        Text(if (isUnlocked) item.name else "Закрыто", fontSize = 9.sp, fontWeight = FontWeight.SemiBold, color = green, maxLines = 1)
                        Text("${item.days} дн.", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }
        }
        Text("Текущая серия: $current дн. · Лучший результат: $best дн.", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable private fun Metric(value: String, label: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontWeight = FontWeight.Bold, fontSize = 21.sp, color = green); Text(label, color = Color.Gray, fontSize = 10.sp) } }

@Composable
private fun CalendarPage(month: YearMonth, records: Map<String, String>, onMonth: (YearMonth) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = { onMonth(month.minusMonths(1)) }) { Text("‹") }
        Text(month.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale("ru"))).replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold)
        TextButton(onClick = { onMonth(month.plusMonths(1)) }) { Text("›") }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) { listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEach { Text(it, fontSize = 11.sp, color = Color.Gray) } }
    val cells = List(month.atDay(1).dayOfWeek.value - 1) { 0 } + (1..month.lengthOfMonth()).toList()
    LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.fillMaxWidth().height(300.dp), userScrollEnabled = false) {
        items(cells) { day ->
            Box(Modifier.aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                if (day > 0) {
                    val date = month.atDay(day); val status = records[date.toString()]
                    val firstTracked = records.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.minOrNull()
                    val c = when { status == "done" -> completed; status == "saved" -> rescued; status == "missed" -> missed; status == null && firstTracked != null && !date.isBefore(firstTracked) && date.isBefore(LocalDate.now()) -> missed; else -> Color(0xFFE9EDEA) }
                    Box(Modifier.fillMaxSize().background(c, CircleShape), contentAlignment = Alignment.Center) { Text("$day", color = if (c == missed || c == completed || c == rescued) Color.White else Color.DarkGray, fontSize = 12.sp) }
                }
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Legend(completed, "Тренировка"); Legend(rescued, "Спасение"); Legend(missed, "Пропуск") }
    val firstTracked = records.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.minOrNull()
    val dates = (1..month.lengthOfMonth()).map { month.atDay(it) }.filter { !it.isAfter(LocalDate.now()) && firstTracked != null && !it.isBefore(firstTracked) }
    val doneCount = dates.count { records[it.toString()] == "done" }
    val pct = if (dates.isEmpty()) 0 else doneCount * 100 / dates.size
    Spacer(Modifier.height(12.dp)); Text("Тренировок за месяц: $doneCount", color = green, fontWeight = FontWeight.SemiBold); Text("Выполнение плана: $pct%", color = Color.Gray, fontSize = 12.sp)
}

@Composable private fun Legend(color: Color, label: String) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(9.dp).background(color, CircleShape)); Spacer(Modifier.width(4.dp)); Text(label, fontSize = 10.sp, color = Color.Gray) } }

@Composable
private fun SettingsPage(t1: String, t2: String, e1: Boolean, e2: Boolean, note: String, onT1: (String) -> Unit, onT2: (String) -> Unit, onE1: (Boolean) -> Unit, onE2: (Boolean) -> Unit, save1: () -> Unit, save2: () -> Unit, clear: () -> Unit) {
    Text("Напоминания", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = green)
    Text("Ежедневные вопросы о тренировке", color = Color.Gray, fontSize = 12.sp)
    ReminderRow("Первое напоминание", t1, e1, onT1, onE1, save1)
    Divider()
    ReminderRow("Второе напоминание", t2, e2, onT2, onE2, save2)
    if (note.isNotBlank()) Text(note, color = green, modifier = Modifier.clickable { clear() }.padding(6.dp))
    Spacer(Modifier.height(12.dp)); Text("Статистика", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = green)
    Text("Общее число тренировок и рекорд серии отображаются на главном экране.", color = Color.Gray, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp)); Text("Daily Streak · версия 2.0", color = Color.Gray, fontSize = 12.sp)
}

@Composable
private fun ReminderRow(title: String, time: String, enabled: Boolean, onTime: (String) -> Unit, onEnabled: (Boolean) -> Unit, save: () -> Unit) {
    var value by remember(title) { mutableStateOf(time) }
    LaunchedEffect(time) { value = time }
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium); Switch(enabled, onEnabled) }
        OutlinedTextField(value, { value = it.take(5); onTime(value) }, label = { Text("Время (ЧЧ:ММ)") }, singleLine = true)
        TextButton(onClick = save) { Text("Сохранить время") }
    }
}

private fun validTime(s: String) = s.matches(Regex("^([01]\\d|2[0-3]):[0-5]\\d$"))
private fun readRecords(p: android.content.SharedPreferences): Map<String, String> = (p.getString("records", "") ?: "").split(";").mapNotNull { val a = it.split("="); if (a.size == 2) a[0] to a[1] else null }.toMap()
private fun writeRecords(r: Map<String, String>) = r.entries.joinToString(";") { "${it.key}=${it.value}" }
private fun streakNow(r: Map<String, String>, today: LocalDate): Int {
    var d = if (r[today.toString()] == "done" || r[today.toString()] == "saved") today else today.minusDays(1)
    if (r[d.toString()] != "done" && r[d.toString()] != "saved") return 0
    var n = 0
    while (r[d.toString()] == "done" || r[d.toString()] == "saved") { n++; d = d.minusDays(1) }
    return n
}
private fun bestStreak(r: Map<String, String>): Int {
    val ds = r.filterValues { it == "done" || it == "saved" }.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.sorted()
    var best = 0; var run = 0; var prev: LocalDate? = null
    for (d in ds) { run = if (prev != null && d == prev!!.plusDays(1)) run + 1 else 1; best = maxOf(best, run); prev = d }
    return best
}
